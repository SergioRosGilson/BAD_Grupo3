-- CIV_VI_mod_Code
-- Author: Sergio, Lucia y Alejandro
-- DateCreated: 5/27/2024 9:33:34 PM
--------------------------------------------------------------
INSERT INTO Types (Type, Kind) VALUES
("YIELD_DNA_BAD", "KIND_YIELD");

INSERT INTO Yields (YieldType, Name, IconString) VALUES
("YIELD_DNA_BAD", "LOC_YIELD_DNA_BAD_NAME", "[ICON_Science]");

--Yield DNA

INSERT INTO	 Types (Type, Kind) VALUES
("BUILDING_CLINICAL_LAB_BAD", "KIND_BUILDING");

INSERT INTO Buildings (BuildingType, Name, PrereqTech, PrereqCivic, Cost, MaxPlayerInstances, MaxWorldInstances, Capital, PrereqDistrict, AdjacentDistrict, Description, RequiresPlacement, RequiresRiver, OuterDefenseHitPoints, Housing, Entertainment, AdjacentResource, Coast, EnabledByReligion, AllowsHolyCity, PurchaseYield, MustPurchase, Maintenance, IsWonder, TraitType, OuterDefenseStrength, CitizenSlots, MustBeLake, MustNotBeLake, RegionalRange, AdjacentToMountain, ObsoleteEra, RequiresReligion, GrantFortification, DefenseModifier, InternalOnly, RequiresAdjacentRiver, Quote, QuoteAudio, MustBeAdjacentLand, AdvisorType, AdjacentCapital, AdjacentImprovement, CityAdjacentTerrain, UnlocksGovernmentPolicy, GovernmentTierRequirement) VALUES
("BUILDING_CLINICAL_LAB_BAD", "LOC_BUILDING_CLINICAL_LAB_BAD_NAME", "TECH_CHEMISTRY", NULL, 620, -1, -1, 0, "DISTRICT_CAMPUS", NULL, "LOC_BUILDING_CLINICAL_LAB_BAD_DESCRIPTION", 0, 0, NULL, 0, 0, NULL, NULL, 0, 0, "YIELD_GOLD", 0, 4, 0, NULL, 0, 1, 0, 0, 0, 0, "NO_ERA", 0, 0, 0, 0, 0, NULL, NULL, 0, "ADVISOR_TECHNOLOGY", 0, NULL, NULL, 0, NULL);

INSERT INTO Building_YieldChanges (BuildingType, YieldType, YieldChange) VALUES
("BUILDING_CLINICAL_LAB_BAD", "YIELD_SCIENCE", 50);

--Clinical Lab

ALTER TABLE UNITS
ADD GeneticallyModified BOOLEAN DEFAULT 0;

--Implementada columna GeneticallyModified

INSERT INTO	 Types (Type, Kind) VALUES
("UNIT_SUPER_SOLDIER_BAD", "KIND_UNIT");
 
INSERT INTO Units (UnitType, Name, BaseSightRange, BaseMoves, Combat, RangedCombat, Range, Bombard, Domain, FormationClass, Cost, PopulationCost, FoundCity, FoundReligion, MakeTradeRoute, EvangelizeBelief, LaunchInquisition, RequiresInquisition, BuildCharges, ReligiousStrength, ReligionEvictPercent, SpreadCharges, ReligiousHealCharges, ExtractsArtifacts, Description, Flavor, CanCapture, CanRetreatWhenCaptured, TraitType, AllowBarbarians, CostProgressionModel, CostProgressionParam1, PromotionClass, InitialLevel, NumRandomChoices, PrereqTech, PrereqCivic, PrereqDistrict, PrereqPopulation, LeaderType, CanTrain, StrategicResource, PurchaseYield, MustPurchase, Maintenance, Stackable, AirSlots, CanTargetAir, PseudoYieldType, ZoneOfControl, AntiAirCombat, Spy, WMDCapable, ParkCharges, IgnoreMoves, TeamVisibility, ObsoleteTech, ObsoleteCivic, MandatoryObsoleteTech, MandatoryObsoleteCivic, AdvisorType, EnabledByReligion, TrackReligion, DisasterCharges, UseMaxMeleeTrainedStrength, ImmediatelyName, CanEarnExperience, GeneticallyModified) VALUES
("UNIT_SUPER_SOLDIER_BAD", "LOC_UNIT_SUPER_SOLDIER_BAD_NAME", 2, 2, 200, 0, 0, 0, "DOMAIN_LAND", "FORMATION_CLASS_LAND_COMBAT", 1000, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "LOC_UNIT_SUPER_SOLDIER_BAD_DESCRIPTION", NULL, 1, 0, NULL, 0, "NO_COSTPROGRESSION", 0, "PROMOTION_CLASS_MELEE", 1, 0, "TECH_FUTURE_TECH", NULL, NULL, NULL, NULL, 1, NULL, "YIELD_GOLD", 1, 6, 0, 0, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, "ADVISOR_CONQUEST", 0, 0, 0, 0, 0, 1, 1);

--Super Soldier

INSERT INTO	 Types (Type, Kind) VALUES
("UNIT_SPRINTER_BAD", "KIND_UNIT");
 
INSERT INTO Units (UnitType, Name, BaseSightRange, BaseMoves, Combat, RangedCombat, Range, Bombard, Domain, FormationClass, Cost, PopulationCost, FoundCity, FoundReligion, MakeTradeRoute, EvangelizeBelief, LaunchInquisition, RequiresInquisition, BuildCharges, ReligiousStrength, ReligionEvictPercent, SpreadCharges, ReligiousHealCharges, ExtractsArtifacts, Description, Flavor, CanCapture, CanRetreatWhenCaptured, TraitType, AllowBarbarians, CostProgressionModel, CostProgressionParam1, PromotionClass, InitialLevel, NumRandomChoices, PrereqTech, PrereqCivic, PrereqDistrict, PrereqPopulation, LeaderType, CanTrain, StrategicResource, PurchaseYield, MustPurchase, Maintenance, Stackable, AirSlots, CanTargetAir, PseudoYieldType, ZoneOfControl, AntiAirCombat, Spy, WMDCapable, ParkCharges, IgnoreMoves, TeamVisibility, ObsoleteTech, ObsoleteCivic, MandatoryObsoleteTech, MandatoryObsoleteCivic, AdvisorType, EnabledByReligion, TrackReligion, DisasterCharges, UseMaxMeleeTrainedStrength, ImmediatelyName, CanEarnExperience, GeneticallyModified) VALUES
("UNIT_SPRINTER_BAD", "LOC_UNIT_SPRINTER_BAD_NAME", 20, 20, 5, 5, 1, 0, "DOMAIN_LAND", "FORMATION_CLASS_LAND_COMBAT", 800, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "LOC_UNIT_SPRINTER_BAD_DESCRIPTION", NULL, 1, 0, NULL, 0, "NO_COSTPROGRESSION", 0, "PROMOTION_CLASS_RECON", 1, 0, "TECH_FUTURE_TECH", NULL, NULL, NULL, NULL, 1, NULL, "YIELD_GOLD", 1, 5, 0, 0, 0, NULL, 1, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, "ADVISOR_CONQUEST", 0, 0, 0, 0, 0, 1, 1);

--Sprinter

INSERT INTO Types (Type, Kind) VALUES
("UNIT_SNIPERMAN_BAD", "KIND_UNIT");

INSERT INTO Units (UnitType, Name, BaseSightRange, BaseMoves, Combat, RangedCombat, Range, Bombard, Domain, FormationClass, Cost, PopulationCost, FoundCity, FoundReligion, MakeTradeRoute, EvangelizeBelief, LaunchInquisition, RequiresInquisition, BuildCharges, ReligiousStrength, ReligionEvictPercent, SpreadCharges, ReligiousHealCharges, ExtractsArtifacts, Description, Flavor, CanCapture, CanRetreatWhenCaptured, TraitType, AllowBarbarians, CostProgressionModel, CostProgressionParam1, PromotionClass, InitialLevel, NumRandomChoices, PrereqTech, PrereqCivic, PrereqDistrict, PrereqPopulation, LeaderType, CanTrain, StrategicResource, PurchaseYield, MustPurchase, Maintenance, Stackable, AirSlots, CanTargetAir, PseudoYieldType, ZoneOfControl, AntiAirCombat, Spy, WMDCapable, ParkCharges, IgnoreMoves, TeamVisibility, ObsoleteTech, ObsoleteCivic, MandatoryObsoleteTech, MandatoryObsoleteCivic, AdvisorType, EnabledByReligion, TrackReligion, DisasterCharges, UseMaxMeleeTrainedStrength, ImmediatelyName, CanEarnExperience, GeneticallyModified) VALUES
("UNIT_SNIPERMAN_BAD", "LOC_UNIT_SNIPERMAN_BAD_NAME", 2, 2, 5, 200, 10, 0, "DOMAIN_LAND", "FORMATION_CLASS_LAND_COMBAT", 900, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "LOC_UNIT_SNIPERMAN_BAD_DESCRIPTION", NULL, 1, 0, NULL, 0, "NO_COSTPROGRESSION", 0, "PROMOTION_CLASS_RANGED", 1, 0, "TECH_FUTURE_TECH", NULL, NULL, NULL, NULL, 1, NULL, "YIELD_GOLD", 1, 6, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, "ADVISOR_CONQUEST", 0, 0, 0, 0, 0, 1, 1);

--SniperMan