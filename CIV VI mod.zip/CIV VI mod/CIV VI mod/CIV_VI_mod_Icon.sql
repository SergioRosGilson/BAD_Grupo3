-- CIV_VI_mod_Icon
-- Author: Sergio, Lucia y Alejandro
-- DateCreated: 5/27/2024 9:38:01 PM
--------------------------------------------------------------
INSERT INTO IconDefinitions (Name, Atlas, "Index") VALUES
("ICON_BUILDING_CLINICAL_LAB_BAD", "ICON_ATLAS_BUILDINGS", 37),
("ICON_BUILDING_CLINICAL_LAB_BAD_FOW", "ICON_ATLAS_BUILDINGS_FOW", 37);

--Clinical Lab

INSERT INTO IconDefinitions (Name, Atlas, "Index") VALUES
("ICON_UNIT_SUPER_SOLDIER_BAD", "ICON_ATLAS_UNITS", 71),
("ICON_UNIT_SUPER_SOLDIER_BAD_FOW", "ICON_ATLAS_UNITS_FOW", 71);

--Super Soldier

INSERT INTO IconDefinitions (Name, Atlas, "Index") VALUES
("ICON_UNIT_SPRINTER_BAD", "ICON_ATLAS_UNITS", 68),
("ICON_UNIT_SPRINTER_BAD_FOW", "ICON_ATLAS_UNITS_FOW", 68);

--Sprinter

INSERT INTO IconDefinitions (Name, Atlas, "Index") VALUES
("ICON_UNIT_SNIPERMAN_BAD", "ICON_ATLAS_UNITS", 83),
("ICON_UNIT_SNIPERMAN_BAD_FOW", "ICON_ATLAS_UNITS_FOW", 83);

--Sniper Man

INSERT INTO IconDefinitions (Name, Atlas, "Index") VALUES
("ICON_YIELD_DNA_BAD", "ICON_ATLAS_YIELDS", 3);

--Yield DNA
