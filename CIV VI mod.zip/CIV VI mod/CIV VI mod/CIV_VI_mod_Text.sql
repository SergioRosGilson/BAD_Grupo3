-- CIV_VI_mod_Text
-- Author: Sergio, Lucia y Alejandro
-- DateCreated: 5/27/2024 9:36:18 PM
--------------------------------------------------------------
INSERT INTO LocalizedText (Language, Tag, Text) VALUES
("en_US", "LOC_BUILDING_CLINICAL_LAB_BAD_NAME", "Clinical Laboratory"),
("en_US", "LOC_BUILDING_CLINICAL_LAB_BAD_DESCRIPTION", "This building is capable of generating DNA-Science and specializes in experimenting with mutations with soldiers for war purposes. Genetics is a long and expensive procedure, so our army of mutants will have to wait for future tech. However, the wait will be worth it."),
("es_ES", "LOC_BUILDING_CLINICAL_LAB_BAD_NAME", "Laboratorio Clinico"),
("es_ES", "LOC_BUILDING_CLINICAL_LAB_BAD_DESCRIPTION", "Este edificio es capaz de generar ADN-Ciencia y se especializa en experimentar mutaciones con soldados con fines belicos. La genetica es un procedimiento largo y costoso, por lo que nuestro ejercito de mutantes debera esperar a las tecnologias del futuro. Sin embargo, la espera valdra la pena.");

--Clinical Lab

INSERT INTO LocalizedText (Language, Tag, Text) VALUES
("en_US", "LOC_UNIT_SUPER_SOLDIER_BAD_NAME", "Super Soldier"),
("en_US", "LOC_UNIT_SUPER_SOLDIER_BAD_DESCRIPTION", "After undergoing a series of genetic experiments, this soldier has acquired superhuman strength."),
("es_ES", "LOC_UNIT_SUPER_SOLDIER_BAD_NAME", "Supersoldado"),
("es_ES", "LOC_UNIT_SUPER_SOLDIER_BAD_DESCRIPTION", "Tras someterse a una serie de experimentos geneticos, este soldado ha adquirido una fuerza sobrehumana.");

--Super Soldier

INSERT INTO LocalizedText (Language, Tag, Text) VALUES
("en_US", "LOC_UNIT_SPRINTER_BAD_NAME", "Sprinter"),
("en_US", "LOC_UNIT_SPRINTER_BAD_DESCRIPTION", "After undergoing a series of genetic experiments, this soldier has acquired great resistance in exchange for lesser strength."),
("es_ES", "LOC_UNIT_SPRINTER_BAD_NAME", "Velocista"),
("es_ES", "LOC_UNIT_SPRINTER_BAD_DESCRIPTION", "Tras someterse a una serie de experimentos geneticos, este soldado ha adquirido una gran resistencia a cambio de una fuerza menor.");

--Sprinter

INSERT INTO LocalizedText (Language, Tag, Text) VALUES
("en_US", "LOC_UNIT_SNIPERMAN_BAD_NAME", "Sniper Man"),
("en_US", "LOC_UNIT_SNIPERMAN_BAD_DESCRIPTION", "After undergoing a series of genetic experiments, this soldier has acquired superhuman vision that allows him to hit enemy vulnerable spots from long distances."),
("es_ES", "LOC_UNIT_SNIPERMAN_BAD_NAME", "Soldado Francotirador"),
("es_ES", "LOC_UNIT_SNIPERMAN_BAD_DESCRIPTION", "Tras someterse a una serie de experimentos geneticos, este soldado ha adquirido una vision sobrehumana que le permite acertar disparos en los puntos vulnerables del enemigo desde largas distancias.");

--Sniper Man

INSERT INTO LocalizedText (Language, Tag, Text) VALUES
("en_US", "LOC_YIELD_DNA_BAD_NAME", "DNA"),
("es_ES", "LOC_YIELD_DNA_BAD_NAME", "ADN");

--Yield DNA